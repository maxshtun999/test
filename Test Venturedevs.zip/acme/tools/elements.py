TEST_DATA = {
    '171.0.2.45': [
        {'name': 'gateway', 'ip_addr': '171.2.0.1'},
        {'name': 'backup-net', 'ip_addr': '173.0.0.1'},
    ],
    '174.0.5.1': [],
}


class MissingVar(Exception):
    pass


class NetworkElement:


    def __init__(self, ip_addr):
        self.__ip_addr = ip_addr
        self.__connected = True
        self.__changed = False
    
    def get_routing_table(self):
        if not self.__connected:
            raise RuntimeError("Disconnected")
        if self.__ip_addr not in TEST_DATA:
            raise MissingVar('no routing table found')
        self.__changed = True
        return JNetRoutingTable(TEST_DATA[self.__ip_addr])
    
    def cleanup(self, action):
        if action == 'commit' or action == 'rollback':
            self.__changed = False
    
    def disconnect(self):
        if self.__changed:
            raise RuntimeError(
                "Tried to disconnect before commiting or rolling back"
            )
        self.__connected = False
    
    def __del__(self):
        if self.__connected:
            print(
                "You must disconnect NetworkElement,"
                " otherwise you'll leak memory!"
            )


class JNetRoutingTable:


    def __init__(self, data):
        self.__data = data
    
    def get_route_by_index(self, index):
        return JNetRoute(self.__data[index])
    
    def get_size(self):
        return len(self.__data)


class JNetRoute:


    def __init__(self, data):
        self.__data = data
    
    def get_name(self):
        return self.__data['name']
    
    def get_ip_addr(self):
        return self.__data['ip_addr']
