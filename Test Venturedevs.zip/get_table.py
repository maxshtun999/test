import sys

import contextlib

import logging

import acme.tools.elements


if __name__ == '__main__':

    @contextlib.contextmanager
    def context():

        network_element = acme.tools.elements.NetworkElement(sys.argv[1])
        print("Enter the block")
        try:
            routing_table = network_element.get_routing_table()  # Fetch table

        except acme.tools.elements.MissingVar:

            logging.exception('No routing table found')  # Record table fault
            network_element.cleanup('rollback')  # Undo partial changes

        else:

            num_routes = routing_table.get_size()  # Determine table size
            for RT_offset in range(num_routes):
                route = routing_table.get_route_by_index(RT_offset)  # Index
                name = route.get_name()  # Route name
                ip_addr = route.get_ip_addr()  # Ip address
                print("%15s -> %s" % (name, ip_addr))  # Format nicely
        finally:

            network_element.cleanup('commit')  # Save changes
            network_element.disconnect()  # Disconnect
