## Situation

Your team is working on a software system for a datacenter company. During your
refinement sessions your PO informed you that company plans to do some huge
changes around networking functionality.

After inspection of the related code and modules it turns out that:
- code was developed a long time ago by someone with Java background
- it functioned properly for years without being touched

Because soon the whole team will have to start delivering new functionality a
decision was made by tech lead and the team to refactor the code first to make
the development that follows easier.

The `acme` library contains logic related to the operating system and is
provided by third party vendor vendor - so it's outside of your power to do any
changes in it. But that shouldn't stop you from delivering pythonic code. Also
`acme` library we gave you is just a stub so that you can run your code locally,
it doesn't contain the real code.

## Your task

You've been given just a single script - `get_table.py` from a much larger code
base related to networking functionality. You have been tasked with refactoring
part of the code and make it pythonic and readable. Don't forget to follow best
practices!

## Tips

You can change every line of code in the `get_table.py` file. The aim of this
task is to change this non-pythonic code into pythonic. Think about
comprehensive solution and design of code. Changing only formatting is not
enough. You can use everything that Python offers (if applicable) i.e.
decorators, context managers, descriptors, property, sequence types, PEP8 etc.

If you have any questions feel free to ask.
